# CareXPS Healthcare CRM - Azure Deployment

## HIPAA-Compliant Healthcare CRM Application

### Quick Deploy to Azure Static Web Apps

This repository is configured for direct deployment to Azure Static Web Apps.

## Deployment Steps

1. **Fork/Clone this repository to GitHub**

2. **Create Azure Static Web App**
   - Go to Azure Portal
   - Create new Static Web App
   - Connect to your GitHub repository
   - Select this repository and branch

3. **Configure Secrets in GitHub**
   Add these secrets to your GitHub repository:
   - `AZURE_STATIC_WEB_APPS_API_TOKEN` (from Azure)
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_ENCRYPTION_KEY`

4. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Deploy CareXPS CRM"
   git push origin main
   ```

## Features

✅ **Maximum Security**
- 1-hour login blocking after 3 failed attempts
- Mandatory MFA for PHI access
- PHI encryption at rest and in transit

✅ **Professional Healthcare CRM**
- Patient management
- Call tracking with Retell AI integration
- SMS communications
- PDF report generation with branding

✅ **Cross-Device Sync**
- Real-time settings synchronization via Supabase
- Offline support with localStorage fallback

## Environment Configuration

Copy `.env.production.template` to `.env.production` and configure your values.

## Build Configuration

- **Framework**: React with Vite
- **Styling**: Tailwind CSS
- **Language**: TypeScript
- **Output**: `dist` folder

## Security Notice

This is a HIPAA-compliant application. All PHI data is encrypted and access is strictly controlled through MFA authentication.

## Support

For deployment issues, check the GitHub Actions tab for build logs.

---

**CareXPS Healthcare CRM** - Secure, Professional, Compliant