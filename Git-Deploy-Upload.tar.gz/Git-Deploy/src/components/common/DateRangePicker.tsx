import React, { useState } from 'react'
import { CalendarIcon, ChevronDownIcon } from 'lucide-react'

export type DateRange = 'today' | 'thisWeek' | 'thisMonth' | 'thisYear' | 'custom'

interface DateRangePickerProps {
  selectedRange: DateRange
  onRangeChange: (range: DateRange, customStart?: Date, customEnd?: Date) => void
  className?: string
}

export const DateRangePicker: React.FC<DateRangePickerProps> = ({
  selectedRange,
  onRangeChange,
  className = ''
}) => {
  const [isOpen, setIsOpen] = useState(false)
  const [customStartDate, setCustomStartDate] = useState('')
  const [customEndDate, setCustomEndDate] = useState('')
  const [showCustomInputs, setShowCustomInputs] = useState(false)

  const dateRangeOptions = [
    { value: 'today' as DateRange, label: 'Today' },
    { value: 'thisWeek' as DateRange, label: 'This Week' },
    { value: 'thisMonth' as DateRange, label: 'This Month' },
    { value: 'thisYear' as DateRange, label: 'This Year' },
    { value: 'custom' as DateRange, label: 'Custom' }
  ]

  const getSelectedLabel = () => {
    const option = dateRangeOptions.find(opt => opt.value === selectedRange)
    return option?.label || 'Select Range'
  }

  const handleRangeSelect = (range: DateRange) => {
    if (range === 'custom') {
      setShowCustomInputs(true)
    } else {
      setShowCustomInputs(false)
      onRangeChange(range)
      setIsOpen(false)
    }
  }

  const handleCustomApply = () => {
    if (customStartDate && customEndDate) {
      const startDate = new Date(customStartDate)
      const endDate = new Date(customEndDate)
      onRangeChange('custom', startDate, endDate)
      setIsOpen(false)
      setShowCustomInputs(false)
    }
  }

  const formatDateForInput = (date: Date) => {
    return date.toISOString().split('T')[0]
  }

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
      >
        <CalendarIcon className="w-4 h-4 text-gray-500 dark:text-gray-400 dark:text-gray-500" />
        <span>{getSelectedLabel()}</span>
        <ChevronDownIcon className={`w-4 h-4 text-gray-500 dark:text-gray-400 dark:text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-72 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-50">
          <div className="p-2">
            {!showCustomInputs ? (
              <div className="space-y-1">
                {dateRangeOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleRangeSelect(option.value)}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600 transition-colors ${
                      selectedRange === option.value
                        ? 'bg-blue-50 text-blue-700 font-medium'
                        : 'text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">Custom Date Range</h3>
                  <button
                    onClick={() => {
                      setShowCustomInputs(false)
                      setIsOpen(false)
                    }}
                    className="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    ×
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Start Date
                    </label>
                    <input
                      type="date"
                      value={customStartDate}
                      onChange={(e) => setCustomStartDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                      End Date
                    </label>
                    <input
                      type="date"
                      value={customEndDate}
                      onChange={(e) => setCustomEndDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => {
                      setShowCustomInputs(false)
                      setCustomStartDate('')
                      setCustomEndDate('')
                    }}
                    className="flex-1 px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-md transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCustomApply}
                    disabled={!customStartDate || !customEndDate}
                    className="flex-1 px-3 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Apply
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Overlay to close dropdown when clicking outside */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => {
            setIsOpen(false)
            setShowCustomInputs(false)
          }}
        />
      )}
    </div>
  )
}

// Utility functions to get date ranges
export const getDateRangeFromSelection = (range: DateRange, customStart?: Date, customEnd?: Date) => {
  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())

  switch (range) {
    case 'today':
      return {
        start: today,
        end: new Date(today.getTime() + 24 * 60 * 60 * 1000 - 1)
      }

    case 'thisWeek':
      const startOfWeek = new Date(today)
      startOfWeek.setDate(today.getDate() - today.getDay())
      startOfWeek.setHours(0, 0, 0, 0) // Ensure start of week is at midnight
      const endOfWeek = new Date(startOfWeek)
      endOfWeek.setDate(startOfWeek.getDate() + 6)
      endOfWeek.setHours(23, 59, 59, 999)
      return { start: startOfWeek, end: endOfWeek }

    case 'thisMonth':
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
      const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0)
      endOfMonth.setHours(23, 59, 59, 999)
      return { start: startOfMonth, end: endOfMonth }

    case 'thisYear':
      const startOfYear = new Date(today.getFullYear(), 0, 1)
      const endOfYear = new Date(today.getFullYear(), 11, 31)
      endOfYear.setHours(23, 59, 59, 999)
      return { start: startOfYear, end: endOfYear }

    case 'custom':
      if (customStart && customEnd) {
        const start = new Date(customStart)
        const end = new Date(customEnd)
        end.setHours(23, 59, 59, 999)
        return { start, end }
      }
      return { start: today, end: today }

    default:
      return { start: today, end: today }
  }
}