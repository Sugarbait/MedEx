import React from 'react'
import {
  MessageSquareIcon,
  SendIcon,
  UserIcon,
  ClockIcon,
  CalendarIcon,
  DollarSignIcon,
  CheckCircleIcon,
  XIcon,
  PhoneIcon,
  DownloadIcon,
  TrendingUpIcon,
  AlertCircleIcon
} from 'lucide-react'

interface SMSDetailModalProps {
  message: {
    message_id: string
    patient_id: string
    phone_number: string
    message_content: string
    direction: 'inbound' | 'outbound'
    status: string
    timestamp: string
    cost?: number
    sentiment_analysis?: {
      overall_sentiment: 'positive' | 'negative' | 'neutral'
      confidence_score: number
    }
    metadata?: {
      patient_name?: string
      message_type?: string
      chat_id?: string
      user_id?: string
      [key: string]: any
    }
  }
  isOpen: boolean
  onClose: () => void
}

export const SMSDetailModal: React.FC<SMSDetailModalProps> = ({ message, isOpen, onClose }) => {
  if (!isOpen) return null

  const formatDateTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString(),
      relative: getRelativeTime(date)
    }
  }

  const getRelativeTime = (date: Date) => {
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 1) {
      const diffInMinutes = Math.floor(diffInHours * 60)
      return `${diffInMinutes} ${diffInMinutes === 1 ? 'minute' : 'minutes'} ago`
    } else if (diffInHours < 24) {
      const hours = Math.floor(diffInHours)
      return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`
    } else {
      const days = Math.floor(diffInHours / 24)
      return `${days} ${days === 1 ? 'day' : 'days'} ago`
    }
  }

  const getSentimentColor = (sentiment?: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-600 bg-green-50 border-green-200'
      case 'negative': return 'text-red-600 bg-red-50 border-red-200'
      case 'neutral': return 'text-yellow-600 bg-yellow-50 border-yellow-200'
      default: return 'text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'text-green-600 bg-green-50'
      case 'sent': return 'text-blue-600 bg-blue-50'
      case 'failed': return 'text-red-600 bg-red-50'
      case 'pending': return 'text-yellow-600 bg-yellow-50'
      default: return 'text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700'
    }
  }

  const getDirectionIcon = () => {
    return message.direction === 'inbound' ? (
      <UserIcon className="w-6 h-6 text-green-600" />
    ) : (
      <SendIcon className="w-6 h-6 text-blue-600" />
    )
  }

  const getDirectionColor = () => {
    return message.direction === 'inbound' ? 'bg-green-100' : 'bg-blue-100'
  }

  const { date, time, relative } = formatDateTime(message.timestamp)
  const messageLength = message.message_content.length
  const smsSegments = Math.ceil(messageLength / 160)

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getDirectionColor()}`}>
              {getDirectionIcon()}
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
                {message.metadata?.patient_name || `Patient ${message.patient_id}`}
              </h2>
              <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                <span>{message.phone_number}</span>
                <span className="flex items-center gap-1">
                  <CalendarIcon className="w-4 h-4" />
                  {date} at {time}
                </span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  message.direction === 'inbound' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                }`}>
                  {message.direction}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <XIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="p-6 space-y-6">
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <ClockIcon className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Sent</span>
                </div>
                <div className="text-lg font-bold text-blue-600">
                  {relative}
                </div>
              </div>

              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUpIcon className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Status</span>
                </div>
                <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(message.status)}`}>
                  {message.status}
                </span>
              </div>

              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <MessageSquareIcon className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Length</span>
                </div>
                <div className="text-lg font-bold text-purple-600">
                  {messageLength} chars
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400">
                  {smsSegments} {smsSegments === 1 ? 'segment' : 'segments'}
                </div>
              </div>

              {message.cost && (
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSignIcon className="w-4 h-4 text-orange-600" />
                    <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Cost</span>
                  </div>
                  <div className="text-lg font-bold text-orange-600">
                    ${message.cost.toFixed(4)}
                  </div>
                </div>
              )}
            </div>

            {/* Contact Information */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">Contact Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Patient Name</label>
                  <p className="text-gray-900 dark:text-gray-100">{message.metadata?.patient_name || 'N/A'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Phone Number</label>
                  <p className="text-gray-900 dark:text-gray-100">{message.phone_number}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Patient ID</label>
                  <p className="text-gray-900 dark:text-gray-100">{message.patient_id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Message Type</label>
                  <p className="text-gray-900 dark:text-gray-100">{message.metadata?.message_type || 'N/A'}</p>
                </div>
                {message.metadata?.chat_id && (
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Chat ID</label>
                    <p className="text-gray-900 dark:text-gray-100 font-mono text-sm">{message.metadata.chat_id}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Sentiment Analysis */}
            {message.sentiment_analysis && (
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">Sentiment Analysis</h3>
                <div className="flex items-center gap-4">
                  <span className={`px-4 py-2 rounded-full text-sm font-medium border ${getSentimentColor(message.sentiment_analysis.overall_sentiment)}`}>
                    {message.sentiment_analysis.overall_sentiment}
                  </span>
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    Confidence: {Math.round(message.sentiment_analysis.confidence_score * 100)}%
                  </span>
                </div>
              </div>
            )}

            {/* Message Content */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">Message Content</h3>
              <div className="bg-white dark:bg-gray-800 rounded border p-4">
                <p className="text-gray-900 dark:text-gray-100 leading-relaxed whitespace-pre-wrap">{message.message_content}</p>
              </div>
              <div className="mt-3 flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                <span>{messageLength} characters</span>
                <span>{smsSegments} SMS {smsSegments === 1 ? 'segment' : 'segments'}</span>
                {message.cost && <span>Cost: ${message.cost.toFixed(4)}</span>}
              </div>
            </div>

            {/* Technical Details */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">Technical Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <label className="text-gray-700 dark:text-gray-300 font-medium">Message ID</label>
                  <p className="text-gray-600 dark:text-gray-400 font-mono">{message.message_id}</p>
                </div>
                <div>
                  <label className="text-gray-700 dark:text-gray-300 font-medium">Direction</label>
                  <p className="text-gray-600 dark:text-gray-400 capitalize">{message.direction}</p>
                </div>
                <div>
                  <label className="text-gray-700 dark:text-gray-300 font-medium">Timestamp</label>
                  <p className="text-gray-600 dark:text-gray-400">{new Date(message.timestamp).toISOString()}</p>
                </div>
                <div>
                  <label className="text-gray-700 dark:text-gray-300 font-medium">Status</label>
                  <p className="text-gray-600 dark:text-gray-400 capitalize">{message.status}</p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
              <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <MessageSquareIcon className="w-4 h-4" />
                Reply
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 dark:bg-gray-700 transition-colors">
                <PhoneIcon className="w-4 h-4" />
                Call Patient
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 dark:bg-gray-700 transition-colors">
                <DownloadIcon className="w-4 h-4" />
                Export
              </button>
              {message.status === 'failed' && (
                <button className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                  <AlertCircleIcon className="w-4 h-4" />
                  Retry Send
                </button>
              )}
              <div className="ml-auto flex items-center gap-2">
                <CheckCircleIcon className="w-4 h-4 text-green-500" />
                <span className="text-sm text-green-600 font-medium">HIPAA Compliant</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}